export { ChildBarrelModule } from './child-barrel.module';
