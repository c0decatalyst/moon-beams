import { Routes } from '@angular/router';
import { HomeComponent } from './components/home';
import { AboutComponent } from './components/about';
import { NoContentComponent } from './components/no-content';

import { DataResolver } from './app.resolver';

export const ROUTES: Routes = [
  { path: '',      outlet: 'mainRegion', component: HomeComponent },
  { path: 'home',  outlet: 'mainRegion', component: HomeComponent },
  { path: 'about', outlet: 'mainRegion', component: AboutComponent },
  // { path: 'detail', outlet: 'mainRegion', loadChildren: './modules/+detail#DetailModule'},
  // { path: 'barrel', outlet: 'messageRegion', loadChildren: './modules/+barrel#BarrelModule'},
  { path: '**',    outlet: 'mainRegion', component: NoContentComponent },
];
